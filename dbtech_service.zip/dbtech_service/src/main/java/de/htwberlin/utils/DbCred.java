package de.htwberlin.utils;

public interface DbCred {
	final String driverClass = "oracle.jdbc.driver.OracleDriver";
	final String url = "jdbc:oracle:thin:@oradbs03.f4.htw-berlin.de:1521:oradb1";
	final String user = "u578897";
	final String password = "p578897";
	final String schema = "u578897";

}
