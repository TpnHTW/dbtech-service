package de.htwberlin.mauterhebung;

import java.sql.Connection;

public interface DAOs {
    void setConnection(Connection connection);
}
